import yfinance as yf
import ta

def analisa_crypto(coin):
    return "SINYAL BELI (contoh)"

def analisa_saham(symbol):
    df = yf.download(symbol, period="10d", interval="1h")
    if df.empty: return None
    df["EMA50"] = df["Close"].ewm(span=50).mean()
    df["EMA200"] = df["Close"].ewm(span=200).mean()
    df["RSI"] = ta.momentum.RSIIndicator(df["Close"]).rsi()
    if df["EMA50"].iloc[-1] > df["EMA200"].iloc[-1] and df["RSI"].iloc[-1] < 70:
        return "Potensi Naik ✅"
    return None