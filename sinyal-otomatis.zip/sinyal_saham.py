import os
from telegram import send_telegram
from helpers.analisa_teknikal import analisa_saham

def cek_sinyal_saham():
    symbols = os.getenv("SAHAM_LIST", "ASII.JK,BBCA.JK").split(',')
    for kode in symbols:
        sinyal = analisa_saham(kode.strip())
        if sinyal:
            send_telegram(f"[SAHAM] {kode.strip()}: {sinyal}")