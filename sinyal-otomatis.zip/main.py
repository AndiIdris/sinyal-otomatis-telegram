from sinyal_crypto import cek_sinyal_crypto
from sinyal_saham import cek_sinyal_saham

if __name__ == "__main__":
    print("🚀 Menjalankan sistem sinyal otomatis...")
    cek_sinyal_crypto()
    cek_sinyal_saham()