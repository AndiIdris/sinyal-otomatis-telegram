import os
from telegram import send_telegram
from helpers.analisa_teknikal import analisa_crypto

def cek_sinyal_crypto():
    coins = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]
    for coin in coins:
        sinyal = analisa_crypto(coin)
        if sinyal:
            send_telegram(f"[CRYPTO] {coin}: {sinyal}")